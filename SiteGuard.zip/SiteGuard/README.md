# SiteGuard

Construction site safety app: a web app that works in any browser, plus iPhone and Android apps.

| Folder | What it is |
|---|---|
| `SiteGuardApp/` | The server (ASP.NET Core 8 + SQLite) **and** the web app. Use it in Visual Studio as before. Start here: `SiteGuardApp/README.md` |
| `SiteGuardMobile/` | The iPhone and Android apps. They show the same screens and connect to the server. See `SiteGuardMobile/README.md` |

## New in this version

- **Vehicles tab - inspections with email to HSE.** Every vehicle or machine has the date its inspection
  is valid until. SiteGuard checks the dates every hour and emails HSE 14 days before an inspection
  ends and again when it has ended. Expired vehicles are marked "do not use". Recording a new inspection
  keeps a history and restarts the reminders.
- **Real site map.** The site plan is drawn on a real map (satellite or street map) with "show my
  position". The demo site is the former Malmi airport in Helsinki; move it to your own site by changing
  two numbers. The weekly heat map is on the real map too.
- **iPhone and Android apps**, and the web app can be added to a phone's home screen.
