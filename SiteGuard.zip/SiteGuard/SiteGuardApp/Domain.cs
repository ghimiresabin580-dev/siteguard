namespace SiteGuard.Domain;

public enum ItemStatus { NotChecked = 0, Ok = 1, Problem = 2 }
public enum SiteItemType { Zone, Gate, Barrier, Walkway, VehicleRoute, LiftArea }
public enum ReportType { Hazard, NearMiss, UnsafeBehaviour }
public enum Severity { Low, Medium, Serious }
public enum DocumentType { TrafficPlan, Permit, LiftPlan }
public enum VehicleType { Excavator, WheelLoader, DumpTruck, Crane, Telehandler, Forklift, LiftingPlatform, Van, Other }

// What HSE has been told about a vehicle's inspection so far
public enum HseNotice { None = 0, EndsSoon = 1, Expired = 2 }

// Anything shown on the site map. Shape holds real map positions as JSON: [[lat, lon], ...].
// Zones and lift areas are areas, barriers, walkways and vehicle routes are lines,
// and a gate is one point.
public class SiteItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public SiteItemType Type { get; set; }
    public ItemStatus Status { get; set; } = ItemStatus.NotChecked;
    public string Shape { get; set; } = "[]";
    public DateTime? LastCheckedUtc { get; set; }
}

// Two-tap report: type + severity. Photo, location and time are added by the app.
public class SafetyReport
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public ReportType Type { get; set; }
    public Severity Severity { get; set; }
    public Guid? SiteItemId { get; set; }
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
    public string? PhotoPath { get; set; }
    public string? Comment { get; set; }
    public string ReportedBy { get; set; } = "";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

// One check of one item during a shift
public class ChecklistEntry
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid SiteItemId { get; set; }
    public ItemStatus Result { get; set; }
    public string? PhotoPath { get; set; }
    public string CheckedBy { get; set; } = "";
    public DateTime CheckedUtc { get; set; } = DateTime.UtcNow;
}

// Saved record of each lift: plan, zone, radio check, weather
public class LiftRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid LiftAreaId { get; set; }
    public string LiftAreaName { get; set; } = "";
    public bool PlanConfirmed { get; set; }
    public bool ZoneClear { get; set; }
    public bool RadioCheckDone { get; set; }
    public bool WeatherOk { get; set; }
    public string? Notes { get; set; }
    public string Operator { get; set; } = "";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;

    public bool IsSafeToLift => PlanConfirmed && ZoneClear && RadioCheckDone && WeatherOk;
}

// Permits and plans with expiry reminders
public class SiteDocument
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "";
    public DocumentType Type { get; set; }
    public string FileUrl { get; set; } = "";
    public DateTime ExpiresUtc { get; set; }
    public bool ReminderSent { get; set; }
}

public class CleaningTask
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Description { get; set; } = "";
    public string? Area { get; set; }
    public string? BeforePhotoPath { get; set; }
    public string? AfterPhotoPath { get; set; }
    public bool Done { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedUtc { get; set; }
}

// One-tap radio message for machine guidance ("Stop", "Area clear", "Reversing")
public class RadioMessage
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Text { get; set; } = "";
    public string SentBy { get; set; } = "";
    public DateTime SentUtc { get; set; } = DateTime.UtcNow;
}

// A machine or vehicle on site. Its inspection is valid up to and including ValidUntil.
public class Vehicle
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";              // for example "Excavator CAT 320"
    public string RegNumber { get; set; } = "";         // registration or fleet number
    public VehicleType Type { get; set; }
    public DateOnly? LastInspected { get; set; }
    public DateOnly ValidUntil { get; set; }
    public string? Notes { get; set; }
    public HseNotice HseNoticeLevel { get; set; } = HseNotice.None;
    public DateTime? HseNotifiedUtc { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

// History: one saved inspection of one vehicle
public class VehicleInspection
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid VehicleId { get; set; }
    public DateOnly InspectedOn { get; set; }
    public DateOnly ValidUntil { get; set; }
    public string? Inspector { get; set; }              // inspection company or person
    public string? Notes { get; set; }
    public string RecordedBy { get; set; } = "";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}
