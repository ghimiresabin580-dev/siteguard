using System.Text.Json;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using SiteGuard.Domain;

var builder = WebApplication.CreateBuilder(args);

// To open the app from a phone on the same Wi-Fi, uncomment the next line and
// browse to http://<your-PC-IP>:5000 (Windows will ask to allow the firewall).
// builder.WebHost.UseUrls("http://0.0.0.0:5000");

builder.Services.AddDbContext<SiteDb>(o => o.UseSqlite("Data Source=siteguard.db"));
builder.Services.AddSignalR();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHostedService<ExpiryReminderService>();

// Vehicle inspections: email settings and the monitor that emails HSE
builder.Services.Configure<EmailOptions>(builder.Configuration.GetSection("Email"));
builder.Services.AddSingleton<Mailer>();
builder.Services.AddSingleton<VehicleInspectionMonitor>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<VehicleInspectionMonitor>());

// The iOS and Android apps load the screens from the phone and call this server,
// so the server must allow their origins (see AppOrigins in appsettings.json).
var appOrigins = builder.Configuration.GetSection("AppOrigins").Get<string[]>()
    ?? new[] { "capacitor://localhost", "ionic://localhost", "http://localhost", "https://localhost" };
builder.Services.AddCors(o => o.AddPolicy("apps", p => p
    .WithOrigins(appOrigins).AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseDefaultFiles();   // serves wwwroot/index.html at "/"
app.UseStaticFiles();
app.UseCors("apps");

Directory.CreateDirectory(Path.Combine(app.Environment.WebRootPath, "uploads"));

// Create the database and sample site on first run
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<SiteDb>();
    db.Database.EnsureCreated();
    if (!DbLayout.IsCurrent(db))
    {
        // The database was made by an older SiteGuard. Keep a copy and start a new one.
        var backup = $"siteguard-backup-{DateTime.Now:yyyyMMdd-HHmmss}.db";
        db.Database.ExecuteSqlRaw("VACUUM INTO '" + backup + "'");
        db.Database.EnsureDeleted();
        db.Database.EnsureCreated();
        app.Logger.LogWarning("The database layout changed. Your old data is saved in {Backup}; a new database was created.", backup);
    }
    Seed.Run(db);
}

app.MapHub<AlertHub>("/alerts");

// ---------- Site map ----------
app.MapGet("/api/items", async (SiteDb db) =>
    await db.SiteItems.OrderBy(i => i.Type).ThenBy(i => i.Name).ToListAsync());

// ---------- Photos (used by reports, checks and cleaning) ----------
app.MapPost("/api/photos", async (IFormFile file, IWebHostEnvironment env) =>
{
    var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
    string[] allowed = [".jpg", ".jpeg", ".png", ".webp", ".heic"];
    if (!allowed.Contains(ext)) return Results.BadRequest("Only photos (jpg, png, webp, heic) are allowed.");
    if (file.Length == 0 || file.Length > 10_000_000) return Results.BadRequest("Photo must be under 10 MB.");

    var name = $"{Guid.NewGuid():N}{ext}";
    var path = Path.Combine(env.WebRootPath, "uploads", name);
    await using (var fs = File.Create(path))
        await file.CopyToAsync(fs);
    return Results.Ok(new { url = $"/uploads/{name}" });
}).DisableAntiforgery();

// ---------- Reports ----------
// Two-tap report. Medium and serious reports mark the place as a problem.
// Serious reports are pushed to everyone who has the app open.
app.MapPost("/api/reports", async (SafetyReport r, SiteDb db, IHubContext<AlertHub> hub) =>
{
    if (!Enum.IsDefined(r.Type) || !Enum.IsDefined(r.Severity))
        return Results.BadRequest("Unknown report type or severity.");
    if (r.PhotoPath != null && !r.PhotoPath.StartsWith("/uploads/"))
        return Results.BadRequest("Invalid photo.");

    r.Id = Guid.NewGuid();
    r.CreatedUtc = DateTime.UtcNow;
    r.ReportedBy = Clean(r.ReportedBy, 60, "Worker");
    r.Comment = string.IsNullOrWhiteSpace(r.Comment) ? null : Clean(r.Comment, 500, "");
    db.Reports.Add(r);

    string? place = null;
    if (r.SiteItemId is { } id)
    {
        var item = await db.SiteItems.FindAsync(id);
        if (item != null)
        {
            place = item.Name;
            if (r.Severity != Severity.Low) item.Status = ItemStatus.Problem;
        }
    }
    await db.SaveChangesAsync();

    if (r.Severity == Severity.Serious)
        await hub.Clients.All.SendAsync("SeriousReport", new
        {
            r.Id, type = r.Type, severity = r.Severity, place, r.Comment, r.ReportedBy, r.CreatedUtc
        });

    return Results.Created($"/api/reports/{r.Id}", r);
});

app.MapGet("/api/reports", async (SiteDb db, int? days) =>
{
    var since = DateTime.UtcNow.AddDays(-(days ?? 7));
    var items = await db.SiteItems.ToDictionaryAsync(i => i.Id, i => i.Name);
    var list = await db.Reports.Where(r => r.CreatedUtc >= since)
        .OrderByDescending(r => r.CreatedUtc).Take(50).ToListAsync();
    return list.Select(r => new
    {
        r.Id, r.Type, r.Severity, r.PhotoPath, r.Comment, r.ReportedBy, r.CreatedUtc,
        place = r.SiteItemId is { } id && items.TryGetValue(id, out var n) ? n : null
    });
});

// ---------- Shift checklist ----------
// Result must be OK or Problem. A Problem also creates a Hazard report so the
// weekly summary and heat map count it.
app.MapPost("/api/checks", async (ChecklistEntry e, SiteDb db) =>
{
    if (e.Result != ItemStatus.Ok && e.Result != ItemStatus.Problem)
        return Results.BadRequest("Result must be OK or Problem.");
    if (e.PhotoPath != null && !e.PhotoPath.StartsWith("/uploads/"))
        return Results.BadRequest("Invalid photo.");
    var item = await db.SiteItems.FindAsync(e.SiteItemId);
    if (item is null) return Results.NotFound();

    e.Id = Guid.NewGuid();
    e.CheckedUtc = DateTime.UtcNow;
    e.CheckedBy = Clean(e.CheckedBy, 60, "Worker");
    item.Status = e.Result;
    item.LastCheckedUtc = e.CheckedUtc;
    db.Checks.Add(e);

    if (e.Result == ItemStatus.Problem)
        db.Reports.Add(new SafetyReport
        {
            Type = ReportType.Hazard, Severity = Severity.Medium, SiteItemId = item.Id,
            PhotoPath = e.PhotoPath, Comment = "Found during shift check",
            ReportedBy = e.CheckedBy
        });

    await db.SaveChangesAsync();
    return Results.Ok(item);
});

// ---------- Lift mode ----------
app.MapPost("/api/lifts", async (LiftRecord l, SiteDb db) =>
{
    if (!l.IsSafeToLift)
        return Results.BadRequest("Lift checklist is not complete.");
    var area = await db.SiteItems.FindAsync(l.LiftAreaId);
    if (area is null || area.Type != SiteItemType.LiftArea)
        return Results.BadRequest("Choose a lift area.");

    l.Id = Guid.NewGuid();
    l.CreatedUtc = DateTime.UtcNow;
    l.LiftAreaName = area.Name;
    l.Operator = Clean(l.Operator, 60, "Worker");
    l.Notes = string.IsNullOrWhiteSpace(l.Notes) ? null : Clean(l.Notes, 300, "");
    db.Lifts.Add(l);
    await db.SaveChangesAsync();
    return Results.Ok(l);
});

app.MapGet("/api/lifts", async (SiteDb db) =>
    await db.Lifts.OrderByDescending(l => l.CreatedUtc).Take(20).ToListAsync());

// ---------- Traffic plans, permits and lift plans ----------
app.MapGet("/api/documents", async (SiteDb db) =>
{
    var now = DateTime.UtcNow;
    var docs = await db.Documents.ToListAsync();
    return docs.OrderBy(d => d.ExpiresUtc).Select(d =>
    {
        var days = (int)Math.Floor((d.ExpiresUtc - now).TotalDays);
        return new
        {
            d.Id, d.Title, d.Type, d.FileUrl, d.ExpiresUtc,
            daysLeft = days,
            state = days < 0 ? "expired" : days <= 7 ? "soon" : "ok"
        };
    });
});

app.MapPost("/api/documents", async (SiteDocument d, SiteDb db) =>
{
    if (string.IsNullOrWhiteSpace(d.Title)) return Results.BadRequest("Title is required.");
    if (!Enum.IsDefined(d.Type)) return Results.BadRequest("Unknown document type.");
    d.FileUrl ??= "";
    if (!((d.FileUrl.StartsWith("/") && !d.FileUrl.StartsWith("//")) || d.FileUrl.StartsWith("https://") || d.FileUrl.StartsWith("http://")))
        return Results.BadRequest("Link must start with /, http:// or https://");

    d.Id = Guid.NewGuid();
    d.Title = Clean(d.Title, 100, "Document");
    d.ReminderSent = false;
    db.Documents.Add(d);
    await db.SaveChangesAsync();
    return Results.Ok(d);
});

// ---------- Vehicle inspections ----------
// Each vehicle has an inspection that is valid until a date. VehicleInspectionMonitor
// emails HSE when it has Email:WarnDaysBefore days left, and again when it has expired.
app.MapGet("/api/vehicles", async (SiteDb db, Mailer mailer) =>
{
    var today = Inspections.Today();
    var warn = mailer.Settings.WarnDaysBefore;
    var history = (await db.VehicleInspections.ToListAsync())
        .GroupBy(i => i.VehicleId)
        .ToDictionary(g => g.Key, g => g.OrderByDescending(i => i.InspectedOn).ThenByDescending(i => i.CreatedUtc).ToList());
    var vehicles = await db.Vehicles.ToListAsync();
    return vehicles.OrderBy(v => v.ValidUntil).ThenBy(v => v.Name).Select(v => new
    {
        v.Id, v.Name, v.RegNumber, v.Type, v.LastInspected, v.ValidUntil, v.Notes,
        v.HseNoticeLevel, v.HseNotifiedUtc,
        daysLeft = Inspections.DaysLeft(v, today),
        state = Inspections.State(v, today, warn),
        history = history.GetValueOrDefault(v.Id) ?? new List<VehicleInspection>()
    });
});

app.MapPost("/api/vehicles", async (NewVehicle n, SiteDb db, VehicleInspectionMonitor monitor) =>
{
    if (string.IsNullOrWhiteSpace(n.Name)) return Results.BadRequest("Name is required.");
    if (!Enum.IsDefined(n.Type)) return Results.BadRequest("Unknown vehicle type.");
    if (n.ValidUntil == default) return Results.BadRequest("Give the date the inspection is valid until.");
    if (n.LastInspected is { } last && (last > Inspections.Today() || last >= n.ValidUntil))
        return Results.BadRequest("The last inspection must be in the past and before the valid-until date.");

    var v = new Vehicle
    {
        Name = Clean(n.Name, 80, "Vehicle"),
        RegNumber = Clean(n.RegNumber, 30, ""),
        Type = n.Type,
        LastInspected = n.LastInspected,
        ValidUntil = n.ValidUntil,
        Notes = string.IsNullOrWhiteSpace(n.Notes) ? null : Clean(n.Notes, 300, "")
    };
    db.Vehicles.Add(v);
    if (n.LastInspected is { } inspectedOn)
        db.VehicleInspections.Add(new VehicleInspection
        {
            VehicleId = v.Id, InspectedOn = inspectedOn, ValidUntil = v.ValidUntil,
            RecordedBy = Clean(n.AddedBy, 60, "Worker")
        });
    await db.SaveChangesAsync();
    monitor.CheckSoon();   // emails HSE right away if this inspection is already ending
    return Results.Ok(v);
});

// Record a new inspection: moves the date forward and starts the HSE reminders again
app.MapPost("/api/vehicles/{id:guid}/inspections", async (Guid id, NewInspection n, SiteDb db, VehicleInspectionMonitor monitor) =>
{
    var v = await db.Vehicles.FindAsync(id);
    if (v is null) return Results.NotFound();
    var today = Inspections.Today();
    if (n.InspectedOn == default || n.InspectedOn > today)
        return Results.BadRequest("Give the inspection date (today or earlier).");
    if (n.ValidUntil <= n.InspectedOn || n.ValidUntil < today)
        return Results.BadRequest("Valid until must be after the inspection date and not in the past.");

    v.LastInspected = n.InspectedOn;
    v.ValidUntil = n.ValidUntil;
    v.HseNoticeLevel = HseNotice.None;
    v.HseNotifiedUtc = null;
    db.VehicleInspections.Add(new VehicleInspection
    {
        VehicleId = v.Id, InspectedOn = n.InspectedOn, ValidUntil = n.ValidUntil,
        Inspector = string.IsNullOrWhiteSpace(n.Inspector) ? null : Clean(n.Inspector, 60, ""),
        Notes = string.IsNullOrWhiteSpace(n.Notes) ? null : Clean(n.Notes, 300, ""),
        RecordedBy = Clean(n.RecordedBy, 60, "Worker")
    });
    await db.SaveChangesAsync();
    monitor.CheckSoon();
    return Results.Ok(v);
});

app.MapDelete("/api/vehicles/{id:guid}", async (Guid id, SiteDb db) =>
{
    var v = await db.Vehicles.FindAsync(id);
    if (v is null) return Results.NotFound();
    db.VehicleInspections.RemoveRange(db.VehicleInspections.Where(i => i.VehicleId == id));
    db.Vehicles.Remove(v);
    await db.SaveChangesAsync();
    return Results.Ok();
});

// "Email HSE now": the inspection status of every vehicle (also a handy email test)
app.MapPost("/api/vehicles/email-hse", async (SiteDb db, Mailer mailer) =>
{
    var o = mailer.Settings;
    var vehicles = (await db.Vehicles.ToListAsync()).OrderBy(v => v.ValidUntil).ThenBy(v => v.Name).ToList();
    if (vehicles.Count == 0) return Results.BadRequest("There are no vehicles yet.");
    var (subject, html, text) = InspectionEmail.Build(vehicles, Inspections.Today(), o, statusReport: true);
    try
    {
        var result = await mailer.SendAsync(o.HseList, subject, html, text);
        return Results.Ok(new { sent = result.Sent, savedTo = result.SavedTo, to = o.HseTo });
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "Could not send the vehicle inspection email");
        return Results.BadRequest("Could not send the email: " + ex.Message);
    }
});

app.MapGet("/api/email/status", (Mailer mailer) =>
{
    var o = mailer.Settings;
    return new { ready = o.SmtpReady, hseTo = o.HseTo, warnDaysBefore = o.WarnDaysBefore };
});

// ---------- Cleaning task list ----------
app.MapGet("/api/cleaning", async (SiteDb db) =>
    await db.CleaningTasks.OrderBy(t => t.Done).ThenByDescending(t => t.CreatedUtc).ToListAsync());

app.MapPost("/api/cleaning", async (NewCleaning n, SiteDb db) =>
{
    if (string.IsNullOrWhiteSpace(n.Description)) return Results.BadRequest("Describe the task.");
    var t = new CleaningTask { Description = Clean(n.Description, 200, ""), Area = string.IsNullOrWhiteSpace(n.Area) ? null : Clean(n.Area, 60, "") };
    db.CleaningTasks.Add(t);
    await db.SaveChangesAsync();
    return Results.Ok(t);
});

// Adding the "after" photo completes the task
app.MapPut("/api/cleaning/{id:guid}", async (Guid id, UpdateCleaning u, SiteDb db) =>
{
    var t = await db.CleaningTasks.FindAsync(id);
    if (t is null) return Results.NotFound();
    if (u.BeforePhotoPath != null)
    {
        if (!u.BeforePhotoPath.StartsWith("/uploads/")) return Results.BadRequest("Invalid photo.");
        t.BeforePhotoPath = u.BeforePhotoPath;
    }
    if (u.AfterPhotoPath != null)
    {
        if (!u.AfterPhotoPath.StartsWith("/uploads/")) return Results.BadRequest("Invalid photo.");
        t.AfterPhotoPath = u.AfterPhotoPath;
        t.Done = true;
        t.CompletedUtc = DateTime.UtcNow;
    }
    await db.SaveChangesAsync();
    return Results.Ok(t);
});

// ---------- Machine guidance: one-tap radio messages ----------
string[] radioTexts = ["Stop", "Area clear", "Reversing"];

app.MapPost("/api/radio", async (RadioRequest m, SiteDb db, IHubContext<AlertHub> hub) =>
{
    if (!radioTexts.Contains(m.Text)) return Results.BadRequest("Unknown radio message.");
    var msg = new RadioMessage { Text = m.Text, SentBy = Clean(m.SentBy, 60, "Worker") };
    db.RadioMessages.Add(msg);
    await db.SaveChangesAsync();
    await hub.Clients.All.SendAsync("Radio", new { msg.Text, msg.SentBy, msg.SentUtc });
    return Results.Ok(msg);
});

app.MapGet("/api/radio", async (SiteDb db) =>
    await db.RadioMessages.OrderByDescending(r => r.SentUtc).Take(20).ToListAsync());

// ---------- Weekly summary and heat map data ----------
app.MapGet("/api/summary", async (SiteDb db, Mailer mailer) =>
{
    var now = DateTime.UtcNow;
    var since = now.AddDays(-7);
    var items = await db.SiteItems.ToListAsync();
    var names = items.ToDictionary(i => i.Id, i => i.Name);
    var reports = await db.Reports.Where(r => r.CreatedUtc >= since).ToListAsync();
    var docs = await db.Documents.ToListAsync();
    var today = Inspections.Today();
    var warn = mailer.Settings.WarnDaysBefore;
    var vehicles = await db.Vehicles.ToListAsync();

    var hotspots = reports.Where(r => r.SiteItemId != null)
        .GroupBy(r => r.SiteItemId!.Value)
        .Select(g => new
        {
            itemId = g.Key,
            name = names.GetValueOrDefault(g.Key, "?"),
            count = g.Count(),
            serious = g.Count(x => x.Severity == Severity.Serious)
        })
        .OrderByDescending(h => h.count).ToList();

    return new
    {
        fromUtc = since, toUtc = now,
        total = reports.Count,
        hazards = reports.Count(r => r.Type == ReportType.Hazard),
        nearMisses = reports.Count(r => r.Type == ReportType.NearMiss),
        unsafeBehaviour = reports.Count(r => r.Type == ReportType.UnsafeBehaviour),
        serious = reports.Count(r => r.Severity == Severity.Serious),
        checks = await db.Checks.CountAsync(c => c.CheckedUtc >= since),
        lifts = await db.Lifts.CountAsync(l => l.CreatedUtc >= since),
        hotspots,
        notCheckedToday = items.Where(i => i.LastCheckedUtc == null || i.LastCheckedUtc < now.AddHours(-24))
            .Select(i => i.Name).ToList(),
        expiringDocuments = docs.Where(d => d.ExpiresUtc <= now.AddDays(14)).OrderBy(d => d.ExpiresUtc)
            .Select(d => new { d.Title, d.ExpiresUtc, expired = d.ExpiresUtc < now }).ToList(),
        warnDays = warn,
        vehicleInspections = vehicles.Where(v => Inspections.DaysLeft(v, today) <= warn).OrderBy(v => v.ValidUntil)
            .Select(v => new { v.Name, v.RegNumber, v.ValidUntil, daysLeft = Inspections.DaysLeft(v, today) }).ToList()
    };
});

app.Run();

static string Clean(string? s, int max, string fallback)
{
    s = s?.Trim();
    if (string.IsNullOrEmpty(s)) return fallback;
    return s.Length > max ? s[..max] : s;
}

record NewCleaning(string Description, string? Area);
record UpdateCleaning(string? BeforePhotoPath, string? AfterPhotoPath);
record RadioRequest(string Text, string? SentBy);
record NewVehicle(string Name, string? RegNumber, VehicleType Type, DateOnly? LastInspected, DateOnly ValidUntil, string? Notes, string? AddedBy);
record NewInspection(DateOnly InspectedOn, DateOnly ValidUntil, string? Inspector, string? Notes, string? RecordedBy);

public class SiteDb(DbContextOptions<SiteDb> options) : DbContext(options)
{
    public DbSet<SiteItem> SiteItems => Set<SiteItem>();
    public DbSet<SafetyReport> Reports => Set<SafetyReport>();
    public DbSet<ChecklistEntry> Checks => Set<ChecklistEntry>();
    public DbSet<LiftRecord> Lifts => Set<LiftRecord>();
    public DbSet<SiteDocument> Documents => Set<SiteDocument>();
    public DbSet<CleaningTask> CleaningTasks => Set<CleaningTask>();
    public DbSet<RadioMessage> RadioMessages => Set<RadioMessage>();
    public DbSet<Vehicle> Vehicles => Set<Vehicle>();
    public DbSet<VehicleInspection> VehicleInspections => Set<VehicleInspection>();
}

public class AlertHub : Hub { }

// Tells whether siteguard.db has the tables and columns this version needs
public static class DbLayout
{
    public static bool IsCurrent(SiteDb db)
    {
        var conn = db.Database.GetDbConnection();
        conn.Open();
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'VehicleInspections'";
            var hasVehicles = Convert.ToInt64(cmd.ExecuteScalar()) > 0;
            cmd.CommandText = "SELECT COUNT(*) FROM pragma_table_info('SiteItems') WHERE name = 'Shape'";
            var hasShapes = Convert.ToInt64(cmd.ExecuteScalar()) > 0;
            return hasVehicles && hasShapes;
        }
        finally
        {
            conn.Close();
        }
    }
}

// Sample site so the app is not empty on first run. Edit or replace with your own.
public static class Seed
{
    // The demo site is drawn on a real map: the former Malmi airport in Helsinki, an open
    // field that is being built into a new district. To move the demo to your own site,
    // change these two numbers to the middle of your site (Google Maps: right-click on
    // the place and click the coordinates to copy them), then delete siteguard.db.
    public const double SiteLat = 60.2539;
    public const double SiteLon = 25.0442;

    // The layout is drawn on a 100 x 64 grid (x to the east, y to the south, 1 unit = 2.6 m)
    // and turned into real map positions around SiteLat/SiteLon.
    static double[] P(double x, double y)
    {
        const double metresPerUnit = 2.6;
        var north = (32 - y) * metresPerUnit;
        var east = (x - 50) * metresPerUnit;
        var lat = SiteLat + north / 111_320.0;
        var lon = SiteLon + east / (111_320.0 * Math.Cos(SiteLat * Math.PI / 180));
        return new[] { Math.Round(lat, 7), Math.Round(lon, 7) };
    }
    static string Area(double x, double y, double w, double h) =>
        JsonSerializer.Serialize(new[] { P(x, y), P(x + w, y), P(x + w, y + h), P(x, y + h) });
    static string Line(params double[][] points) => JsonSerializer.Serialize(points);
    static string Point(double x, double y) => JsonSerializer.Serialize(new[] { P(x, y) });

    public static void Run(SiteDb db)
    {
        if (!db.SiteItems.Any())
        {
            SiteItem I(string n, SiteItemType t, string shape) => new() { Name = n, Type = t, Shape = shape };

            db.SiteItems.AddRange(
                I("Zone A", SiteItemType.Zone, Area(6, 7, 30, 17)),
                I("Zone B", SiteItemType.Zone, Area(40, 7, 26, 17)),
                I("Zone C", SiteItemType.Zone, Area(70, 7, 24, 17)),
                I("Zone D", SiteItemType.Zone, Area(12, 34, 24, 12)),
                I("North fence", SiteItemType.Barrier, Line(P(3, 3.5), P(97, 3.5))),
                I("Crane barrier", SiteItemType.Barrier, Line(P(38, 32), P(63.5, 32), P(63.5, 48))),
                I("Vehicle route", SiteItemType.VehicleRoute, Line(P(8, 28), P(66.5, 28), P(66.5, 60.5))),
                I("Walkway west", SiteItemType.Walkway, Line(P(3.5, 8), P(3.5, 55))),
                I("Walkway south", SiteItemType.Walkway, Line(P(3.5, 55), P(62, 55))),
                I("Crane lift area", SiteItemType.LiftArea, Area(40, 34, 22, 13)),
                I("Storage lift area", SiteItemType.LiftArea, Area(70, 34, 22, 12)),
                I("Main gate", SiteItemType.Gate, Point(66.5, 61.5)),
                I("Side gate", SiteItemType.Gate, Point(97, 16)));
        }

        if (!db.Documents.Any())
        {
            var now = DateTime.UtcNow;
            db.Documents.AddRange(
                new SiteDocument { Title = "Traffic plan", Type = DocumentType.TrafficPlan, FileUrl = "/docs/sample.html?name=Traffic%20plan", ExpiresUtc = now.AddDays(30) },
                new SiteDocument { Title = "Hot work permit", Type = DocumentType.Permit, FileUrl = "/docs/sample.html?name=Hot%20work%20permit", ExpiresUtc = now.AddDays(5) },
                new SiteDocument { Title = "Crane lift plan", Type = DocumentType.LiftPlan, FileUrl = "/docs/sample.html?name=Crane%20lift%20plan", ExpiresUtc = now.AddDays(60) });
        }

        if (!db.CleaningTasks.Any())
        {
            db.CleaningTasks.AddRange(
                new CleaningTask { Description = "Clear packaging from walkway", Area = "Walkway south" },
                new CleaningTask { Description = "Sweep mud off vehicle route", Area = "Vehicle route" },
                new CleaningTask { Description = "Tidy material storage", Area = "Zone D" });
        }

        // Demo vehicles: one ends in 9 days and one has expired, so HSE gets an email on first run
        if (!db.Vehicles.Any())
        {
            var today = Inspections.Today();
            Vehicle V(string name, string reg, VehicleType type, int daysLeft) => new()
            {
                Name = name, RegNumber = reg, Type = type,
                ValidUntil = today.AddDays(daysLeft),
                LastInspected = today.AddDays(daysLeft).AddYears(-1)
            };
            var demo = new[]
            {
                V("Excavator CAT 320", "EXC-01", VehicleType.Excavator, 9),
                V("Wheel loader Volvo L90", "WL-02", VehicleType.WheelLoader, -3),
                V("Mobile crane Liebherr LTM 1050", "CR-03", VehicleType.Crane, 45),
                V("Dump truck Scania", "ABC-123", VehicleType.DumpTruck, 160),
                V("Telehandler JCB 540", "TH-05", VehicleType.Telehandler, 220)
            };
            db.Vehicles.AddRange(demo);
            db.VehicleInspections.AddRange(demo.Select(v => new VehicleInspection
            {
                VehicleId = v.Id, InspectedOn = v.LastInspected!.Value, ValidUntil = v.ValidUntil,
                Inspector = "Inspection company (demo)", RecordedBy = "Demo data"
            }));
        }
        db.SaveChanges();
    }
}

// Runs hourly and warns about documents that expire within 7 days (or already expired)
public class ExpiryReminderService(IServiceScopeFactory scopes, IHubContext<AlertHub> hub) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                using var scope = scopes.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<SiteDb>();
                var limit = DateTime.UtcNow.AddDays(7);

                var expiring = await db.Documents
                    .Where(d => !d.ReminderSent && d.ExpiresUtc <= limit)
                    .ToListAsync(ct);

                foreach (var d in expiring)
                {
                    await hub.Clients.All.SendAsync("DocumentExpiring", d.Title, d.ExpiresUtc, ct);
                    d.ReminderSent = true;
                }
                await db.SaveChangesAsync(ct);
                await Task.Delay(TimeSpan.FromHours(1), ct);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception) { await Task.Delay(TimeSpan.FromMinutes(1), ct); }
        }
    }
}
