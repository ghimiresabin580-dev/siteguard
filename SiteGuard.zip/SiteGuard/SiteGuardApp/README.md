# SiteGuard (server + web app)

Backend (ASP.NET Core 8 + SQLite + SignalR) and the phone-friendly web app, in one project.
The iPhone and Android apps are in the `SiteGuardMobile` folder next to this one.

## Files

- `app.csproj`, `Program.cs`, `Domain.cs`, `VehicleInspections.cs` - backend
- `appsettings.json` - settings, including the HSE email settings
- `wwwroot/index.html`, `style.css`, `app.js` - the app screens
- `wwwroot/lib/leaflet` - the map library (Leaflet 1.9.4)
- `wwwroot/manifest.json`, `wwwroot/icons` - lets people install the web app on a phone's home screen
- `wwwroot/docs/sample.html` - placeholder for the sample permits
- `wwwroot/signals/` - put your approved hand signal pictures here

## Install into your Visual Studio project (project folder: `...\repos\app\app\`)

1. Stop the app and close Visual Studio.
2. In the project folder, delete `bin` and `obj`.
3. Copy `app.csproj`, `Program.cs`, `Domain.cs`, `VehicleInspections.cs`, `appsettings.json` and the whole
   `wwwroot` folder into the project folder. Replace existing files. Delete any other `.cs` files.
4. Open `app.sln`, right-click the Solution > Restore NuGet Packages (this adds **MailKit**, used for email),
   then Build > Rebuild Solution.
5. Press F5 and open `http://localhost:5000`.

You do **not** need to delete `siteguard.db` this time. When the app starts and finds a database made by
an older SiteGuard, it saves a copy as `siteguard-backup-<date>.db` and creates a new one with the demo
site. (If another program has `siteguard.db` open, close it first.)

## Vehicle inspections and email to HSE

The **Vehicles** tab lists every vehicle or machine and the date its inspection is valid until.

- SiteGuard checks the dates when it starts, every hour, and right after a vehicle is added or changed.
- HSE gets **one email when an inspection has 14 days left** and **one more when it has expired**.
  Several vehicles at the same time go in one email. Everyone with the app open also sees an alert.
- An expired vehicle is shown in red with "do not use".
- **Record new inspection** saves the new dates (and keeps a history), so the reminders start again.
- **Email HSE the inspection status now** sends a list of all vehicles. Use it to test the email settings.

### Setting up the email

Until you do this, every HSE email is saved as a file in the `mail-outbox` folder in the project folder.
Double-click an `.eml` file to see what HSE would get.

Fill in the `Email` section of `appsettings.json`:

| Setting | What to put |
|---|---|
| `SmtpHost` | Mail server, for example `smtp.gmail.com` or your company's server |
| `SmtpPort` | Usually `587` (or `465`, or `25` for a company relay without a password) |
| `Security` | `Auto` works for most servers |
| `UserName`, `Password` | The mail account SiteGuard sends from (leave empty for a relay without a password) |
| `From` | Sender address, usually the same as `UserName` |
| `HseTo` | HSE address. More than one: `hse@company.fi, safety@company.fi` |
| `WarnDaysBefore` | Days before the end of an inspection for the first email (default 14) |
| `AppUrl` | Optional. The address of SiteGuard, so the email has an "Open SiteGuard" link |

**Gmail:** turn on 2-Step Verification for the Google account, create an **App password**
(Google Account > Security > App passwords), and use it as `Password`.
`SmtpHost` = `smtp.gmail.com`, `SmtpPort` = `587`, `UserName` and `From` = the Gmail address.

**Microsoft 365 / Outlook:** Microsoft is turning off password sign-in for SMTP by default for existing
company accounts in late December 2026. Ask your IT team for an SMTP relay address SiteGuard can use, or use another
mail account.

**Keep the password out of `appsettings.json`:** right-click the project > **Manage User Secrets** and put
this there instead:

```json
{ "Email": { "Password": "your-app-password" } }
```

Changes to the email settings are picked up without restarting.

## Real site map

The site plan is drawn on a real map. Tap **Layers** (top right) to switch between **Satellite** and
**Street map**, and 📍 to show where you are. The phone needs internet to load the map pictures.

The demo site is the former Malmi airport in Helsinki (an open field that is being built into a new
district). To put the demo on your own site:

1. In Google Maps, right-click the middle of your site and click the coordinates to copy them.
2. In `Program.cs`, find `SiteLat` and `SiteLon` in the `Seed` class and paste the two numbers.
3. Delete `siteguard.db` (and `siteguard.db-shm`, `siteguard.db-wal`) and start the app.

Each item's shape is a list of real positions (`Shape` in `Domain.cs`), so you can also draw your real
zones, fences and routes: edit the `I(...)` lines in `Seed`.

The satellite pictures come from Esri and the street map from OpenStreetMap. That is fine for a demo; for
a company app with many users, get a free map key (for example from ArcGIS or MapTiler) and change the
two map addresses at the top of the map code in `app.js`.

## Try it on a phone

To open the app from a phone on the same Wi-Fi, uncomment the `UseUrls` line in `Program.cs`, run again,
and browse to `http://<your-PC-IP>:5000`. Camera works over plain http. Browser GPS (📍 and the place of a
report) only works on `https://`, `localhost`, or in the iPhone/Android app.

**Install the web app on the home screen:** on iPhone, open it in Safari > Share > Add to Home Screen.
On Android, Chrome menu > Add to Home screen (or Install app).

**iPhone and Android apps:** see `SiteGuardMobile/README.md`.

## Sample data

13 map items, 3 permits (one expires in 5 days, so you see a reminder), 3 cleaning tasks, and
5 vehicles: one inspection expired 3 days ago and one ends in 9 days, so HSE gets an email (or an
`.eml` file in `mail-outbox`) the first time you start the app. Edit `Seed` at the bottom of
`Program.cs` to describe your real site.
