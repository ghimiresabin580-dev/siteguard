using System.Globalization;
using System.Net;
using System.Text;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MimeKit;
using SiteGuard.Domain;

// Settings from the "Email" section of appsettings.json (see README)
public class EmailOptions
{
    public string SmtpHost { get; set; } = "";          // empty = emails are saved in the mail-outbox folder instead
    public int SmtpPort { get; set; } = 587;
    public string Security { get; set; } = "Auto";      // Auto, StartTls, SslOnConnect or None
    public string UserName { get; set; } = "";
    public string Password { get; set; } = "";
    public string From { get; set; } = "";
    public string FromName { get; set; } = "SiteGuard";
    public string HseTo { get; set; } = "";             // HSE address(es), separated by , or ;
    public int WarnDaysBefore { get; set; } = 14;       // first email this many days before the inspection ends
    public string AppUrl { get; set; } = "";            // optional link in the email, e.g. https://siteguard.example.com

    public bool SmtpReady => !string.IsNullOrWhiteSpace(SmtpHost);
    public List<string> HseList =>
        HseTo.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
}

public record MailResult(bool Sent, string? SavedTo);

// Sends email with MailKit. Until SMTP is set up, each email is saved as an .eml file
// in the mail-outbox folder, so you can open it and see what HSE would get.
public class Mailer(IOptionsMonitor<EmailOptions> options, IWebHostEnvironment env, ILogger<Mailer> log)
{
    public EmailOptions Settings => options.CurrentValue;

    public async Task<MailResult> SendAsync(IEnumerable<string> to, string subject, string html, string text, CancellationToken ct = default)
    {
        var o = Settings;
        var msg = new MimeMessage();
        msg.From.Add(new MailboxAddress(o.FromName, string.IsNullOrWhiteSpace(o.From) ? "siteguard@localhost" : o.From.Trim()));
        foreach (var address in to)
        {
            if (MailboxAddress.TryParse(address, out var mailbox)) msg.To.Add(mailbox);
            else log.LogWarning("Skipping invalid email address {Address}", address);
        }
        msg.Subject = subject;
        msg.Body = new BodyBuilder { HtmlBody = html, TextBody = text }.ToMessageBody();

        if (!o.SmtpReady)
        {
            var dir = Path.Combine(env.ContentRootPath, "mail-outbox");
            Directory.CreateDirectory(dir);
            var file = Path.Combine(dir, $"{DateTime.Now:yyyy-MM-dd_HHmmss}_{Guid.NewGuid().ToString("N")[..6]}.eml");
            await using (var fs = File.Create(file))
                await msg.WriteToAsync(fs, ct);
            log.LogWarning("Email is not set up (Email:SmtpHost is empty), so the email was saved to {File}", file);
            return new MailResult(false, file);
        }

        if (msg.To.Count == 0)
            throw new InvalidOperationException("There is no HSE email address. Set Email:HseTo in appsettings.json.");

        using var smtp = new SmtpClient { Timeout = 30_000 };
        var security = Enum.TryParse<SecureSocketOptions>(o.Security, true, out var s) ? s : SecureSocketOptions.Auto;
        await smtp.ConnectAsync(o.SmtpHost.Trim(), o.SmtpPort, security, ct);
        if (!string.IsNullOrWhiteSpace(o.UserName))
            await smtp.AuthenticateAsync(o.UserName.Trim(), o.Password, ct);
        await smtp.SendAsync(msg, ct);
        await smtp.DisconnectAsync(true, ct);
        log.LogInformation("Sent email '{Subject}' to {To}", subject, string.Join(", ", msg.To));
        return new MailResult(true, null);
    }
}

public static class Inspections
{
    // Dates are the server's local dates (an inspection is valid all day on its last day)
    public static DateOnly Today() => DateOnly.FromDateTime(DateTime.Now);

    public static int DaysLeft(Vehicle v, DateOnly today) => v.ValidUntil.DayNumber - today.DayNumber;

    // What HSE should know about this vehicle today
    public static HseNotice NoticeNeeded(Vehicle v, DateOnly today, int warnDays)
    {
        var days = DaysLeft(v, today);
        return days < 0 ? HseNotice.Expired : days <= warnDays ? HseNotice.EndsSoon : HseNotice.None;
    }

    public static string State(Vehicle v, DateOnly today, int warnDays) => NoticeNeeded(v, today, warnDays) switch
    {
        HseNotice.Expired => "expired",
        HseNotice.EndsSoon => "soon",
        _ => "ok"
    };

    public static string StatusText(int days) =>
        days < 0 ? $"EXPIRED {-days} day{(days == -1 ? "" : "s")} ago"
        : days == 0 ? "Ends today"
        : $"Ends in {days} day{(days == 1 ? "" : "s")}";
}

// The email HSE gets
public static class InspectionEmail
{
    public static (string Subject, string Html, string Text) Build(
        IReadOnlyList<Vehicle> vehicles, DateOnly today, EmailOptions o, bool statusReport)
    {
        var expired = vehicles.Count(v => Inspections.DaysLeft(v, today) < 0);
        var attention = vehicles.Count(v => Inspections.DaysLeft(v, today) <= o.WarnDaysBefore);

        string subject;
        if (statusReport)
            subject = $"SiteGuard: vehicle inspection status ({attention} of {vehicles.Count} need attention)";
        else if (vehicles.Count == 1)
            subject = (expired == 1 ? "Vehicle inspection EXPIRED: " : "Vehicle inspection ends soon: ") + Label(vehicles[0]);
        else
            subject = $"Vehicle inspections need attention: {vehicles.Count} vehicles" + (expired > 0 ? $", {expired} expired" : "");

        var intro = statusReport
            ? $"Inspection status of all {vehicles.Count} vehicles on site. {attention} need attention."
            : "The inspection of these vehicles is ending or has ended. Please book a new inspection. " +
              "A vehicle whose inspection has expired must not be used on site.";
        var footer = $"Sent by SiteGuard on {DateTime.Now.ToString("d MMM yyyy HH:mm", CultureInfo.InvariantCulture)}. " +
                     $"HSE gets one email when an inspection has {o.WarnDaysBefore} days left and another when it has expired.";
        var link = string.IsNullOrWhiteSpace(o.AppUrl) ? null : o.AppUrl.Trim().TrimEnd('/') + "/#vehicles";

        var html = new StringBuilder();
        html.Append("<div style=\"font-family:Segoe UI,Arial,sans-serif;color:#0f172a;max-width:680px\">");
        html.Append("<h2 style=\"margin:0 0 8px;color:#0f2a43\">Vehicle inspections</h2>");
        html.Append($"<p>{Enc(intro)}</p>");
        html.Append("<table cellpadding=\"8\" cellspacing=\"0\" style=\"border-collapse:collapse;width:100%;font-size:14px\">");
        html.Append("<tr style=\"background:#0f2a43;color:#ffffff;text-align:left\"><th>Vehicle</th><th>Reg. / ID</th><th>Valid until</th><th>Status</th></tr>");

        var text = new StringBuilder();
        text.AppendLine(intro).AppendLine();

        foreach (var v in vehicles)
        {
            var days = Inspections.DaysLeft(v, today);
            var status = days > o.WarnDaysBefore ? $"Valid ({days} days left)" : Inspections.StatusText(days);
            var color = days < 0 ? "#dc2626" : days <= o.WarnDaysBefore ? "#b45309" : "#15803d";
            var until = v.ValidUntil.ToString("d MMM yyyy", CultureInfo.InvariantCulture);

            html.Append("<tr style=\"border-bottom:1px solid #e2e8f0\">");
            html.Append($"<td><b>{Enc(v.Name)}</b></td><td>{Enc(v.RegNumber)}</td><td>{until}</td>");
            html.Append($"<td style=\"color:{color};font-weight:bold\">{Enc(status)}</td></tr>");

            text.AppendLine($"- {Label(v)}: valid until {until}. {status}");
        }
        html.Append("</table>");
        if (link != null)
        {
            html.Append($"<p><a href=\"{Enc(link)}\" style=\"color:#0f2a43;font-weight:bold\">Open SiteGuard</a></p>");
            text.AppendLine().AppendLine($"Open SiteGuard: {link}");
        }
        html.Append($"<p style=\"color:#64748b;font-size:12px\">{Enc(footer)}</p></div>");
        text.AppendLine().AppendLine(footer);

        return (subject, html.ToString(), text.ToString());
    }

    private static string Label(Vehicle v) => string.IsNullOrWhiteSpace(v.RegNumber) ? v.Name : $"{v.Name} ({v.RegNumber})";
    private static string Enc(string? s) => WebUtility.HtmlEncode(s ?? "");
}

// Checks every vehicle at start-up, every hour, and right after a vehicle is added or
// renewed. Emails HSE once when an inspection has WarnDaysBefore days left and once
// more when it has expired. If sending fails, nothing is marked, so it tries again.
public class VehicleInspectionMonitor(
    IServiceScopeFactory scopes, IHubContext<AlertHub> hub, Mailer mailer, ILogger<VehicleInspectionMonitor> log)
    : BackgroundService
{
    private readonly SemaphoreSlim _wake = new(0);

    public void CheckSoon()
    {
        if (_wake.CurrentCount == 0) _wake.Release();
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { await CheckAsync(ct); }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
            catch (Exception ex) { log.LogError(ex, "Vehicle inspection check failed"); }

            try { await _wake.WaitAsync(TimeSpan.FromHours(1), ct); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task CheckAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<SiteDb>();
        var o = mailer.Settings;
        var today = Inspections.Today();

        var toTell = new List<(Vehicle Vehicle, HseNotice Notice)>();
        foreach (var v in await db.Vehicles.ToListAsync(ct))
        {
            var needed = Inspections.NoticeNeeded(v, today, o.WarnDaysBefore);
            if (needed > v.HseNoticeLevel) toTell.Add((v, needed));
            else if (needed < v.HseNoticeLevel) v.HseNoticeLevel = needed;   // the date was moved later
        }

        MailResult? result = null;
        if (toTell.Count > 0)
        {
            var list = toTell.Select(t => t.Vehicle).OrderBy(v => v.ValidUntil).ToList();
            var (subject, html, text) = InspectionEmail.Build(list, today, o, statusReport: false);
            try
            {
                result = await mailer.SendAsync(o.HseList, subject, html, text, ct);
                foreach (var (v, notice) in toTell)
                {
                    v.HseNoticeLevel = notice;
                    v.HseNotifiedUtc = DateTime.UtcNow;
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                log.LogError(ex, "Could not email HSE about {Count} vehicle inspection(s). Trying again within an hour.", toTell.Count);
            }
        }
        await db.SaveChangesAsync(ct);

        if (result != null)
        {
            var expired = toTell.Count(t => t.Notice == HseNotice.Expired);
            var who = result.Sent ? "HSE has been emailed." : "HSE email saved (email is not set up yet).";
            var first = toTell[0].Vehicle;
            var text = toTell.Count == 1
                ? (expired == 1 ? $"Inspection EXPIRED: {first.Name}. Do not use it. " : $"Inspection ends soon: {first.Name}. ") + who
                : $"{toTell.Count} vehicle inspections need attention ({expired} expired). " + who;
            await hub.Clients.All.SendAsync("VehicleInspection", new { text, expired = expired > 0 }, ct);
        }
    }
}
