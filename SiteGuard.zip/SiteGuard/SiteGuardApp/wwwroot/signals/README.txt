Put your company's approved hand signal pictures here as PNG files.
The Machines screen shows them automatically when the file names match:

  stop.png            emergency-stop.png
  raise.png           lower.png
  move-forward.png    move-back.png
  turn-left.png       turn-right.png

Use the signals your site and crane/machine standard require. SiteGuard does not
draw them for you, so every picture is the official one.
