# SiteGuard for iPhone and Android

These are the iPhone and Android apps (made with Capacitor 8). They show the same screens as the web app
(copied from `../SiteGuardApp/wwwroot`) and talk to your SiteGuard server. Keep this folder next to the
`SiteGuardApp` folder.

## What you need

- **Node.js 22 or newer** (nodejs.org)
- **Android:** Android Studio (latest)
- **iPhone:** a Mac with Xcode (latest) and an Apple ID. iPhone apps can only be built on a Mac.
- The SiteGuard server running, and reachable from the phone (see below)

## First time

Open a terminal (Command Prompt on Windows) in this folder and run:

```
npm install
npm run setup
```

`setup` creates the `android` and `ios` projects and adds everything SiteGuard needs: GPS and camera
permissions, the SiteGuard icon and start screen, and permission to use a test server on your Wi-Fi.

## Run on Android

```
npm run android
```

Android Studio opens. Pick your phone (USB debugging on) or an emulator and press **Run**.
To get an installable file: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

## Run on iPhone (on a Mac)

```
npm install
npm run setup
npm run ios
```

Xcode opens. Click **App** in the left list > **Signing & Capabilities** > pick your **Team**
(your Apple ID). Plug in the iPhone, select it at the top and press **Run**.

## Connecting to the server

On first start the app asks for the **server address**. Tap ⚙️ in the header to change it later.

| Where the server runs | Address to type |
|---|---|
| Your PC, phone on the same Wi-Fi | `http://<your-PC-IP>:5000`, e.g. `http://192.168.1.20:5000`. In `Program.cs`, uncomment the `UseUrls` line first and allow port 5000 in the Windows firewall. |
| Your PC, Android emulator | `http://10.0.2.2:5000` |
| Your Mac, iPhone simulator | `http://localhost:5000` |
| A real server | `https://siteguard.yourcompany.com` |

To find your PC's IP on Windows, run `ipconfig` and look for "IPv4 Address".

## After you change the web app

The apps carry their own copy of the screens. After changing anything in `SiteGuardApp/wwwroot`, run
`npm run sync` (or `npm run android` / `npm run ios`) and run the app again.

## Before giving the app to other people

- Change `appId` in `capacitor.config.json` to your own, like `com.yourcompany.siteguard`, before
  you run `npm run setup` (or delete the `android` and `ios` folders and run it again).
- Host the server on `https://`. Plain `http` is allowed only so you can test on your Wi-Fi. When the server
  has https, remove `"cleartext": true` from `capacitor.config.json` and the `NSAppTransportSecurity`
  block from `ios/App/App/Info.plist`.
