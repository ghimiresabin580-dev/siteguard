// Copies the SiteGuard screens from the web app (../SiteGuardApp/wwwroot) into www/,
// which Capacitor puts inside the iOS and Android apps. Photos, documents and hand
// signal pictures stay on the server, so they are not copied.
import { cpSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const web = join(root, '..', 'SiteGuardApp', 'wwwroot');
const www = join(root, 'www');

if (!existsSync(join(web, 'index.html'))) {
  console.error(`Cannot find the web app at ${web}. Keep SiteGuardMobile next to the SiteGuardApp folder.`);
  process.exit(1);
}

rmSync(www, { recursive: true, force: true });
mkdirSync(www);
for (const name of ['index.html', 'app.js', 'style.css', 'manifest.json', 'icons', 'lib']) {
  cpSync(join(web, name), join(www, name), { recursive: true });
}
console.log(`Copied the web app into ${www}`);
