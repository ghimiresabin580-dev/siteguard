// Creates the Android and iOS projects and sets them up for SiteGuard. Run it once:
//   npm install
//   npm run setup
// It is safe to run again: steps that are already done are skipped.
import { execSync } from 'node:child_process';
import { cpSync, existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const run = cmd => { console.log(`\n> ${cmd}`); execSync(cmd, { cwd: root, stdio: 'inherit' }); };
const edit = (file, change) => {
  const path = join(root, file);
  if (!existsSync(path)) return console.warn(`  (skipped, not found: ${file})`);
  const before = readFileSync(path, 'utf8');
  const after = change(before);
  if (after !== before) { writeFileSync(path, after); console.log(`  updated ${file}`); }
};
const copy = (from, to) => { cpSync(join(root, from), join(root, to), { recursive: true }); console.log(`  copied ${from} -> ${to}`); };

run('node scripts/copy-web.mjs');

// ---------- Android ----------
if (!existsSync(join(root, 'android'))) run('npx cap add android');
console.log('\nSetting up Android...');
edit('android/app/src/main/AndroidManifest.xml', s => s.includes('ACCESS_FINE_LOCATION') ? s : s.replace(
  '<uses-permission android:name="android.permission.INTERNET" />',
  `<uses-permission android:name="android.permission.INTERNET" />
    <!-- GPS: "show my position" on the map and the place of a report -->
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />`));
edit('android/app/src/main/res/values/ic_launcher_background.xml', s => s.replace(/#FFFFFF/i, '#0F2A43'));
copy('resources/android/res', 'android/app/src/main/res');

// ---------- iOS (the project can be made on any computer; building needs a Mac) ----------
let iosOk = true;
try {
  if (!existsSync(join(root, 'ios'))) run('npx cap add ios');
} catch {
  iosOk = false;
  console.warn('\nThe iOS project could not be created here. Run "npm run setup" again on a Mac.');
}
if (iosOk) {
  console.log('\nSetting up iOS...');
  edit('ios/App/App/Info.plist', s => {
    if (s.includes('NSCameraUsageDescription')) return s;
    // light status bar text on the navy header
    s = s.replace(/<key>UIViewControllerBasedStatusBarAppearance<\/key>\s*<true\/>/,
      '<key>UIViewControllerBasedStatusBarAppearance</key>\n\t<false/>');
    const keys = `	<key>NSCameraUsageDescription</key>
	<string>SiteGuard uses the camera to add photos to reports, checks and cleaning tasks.</string>
	<key>NSPhotoLibraryUsageDescription</key>
	<string>SiteGuard lets you pick a photo for a report, check or cleaning task.</string>
	<key>NSLocationWhenInUseUsageDescription</key>
	<string>SiteGuard shows where you are on the site map and adds the place to your reports.</string>
	<key>NSLocalNetworkUsageDescription</key>
	<string>SiteGuard connects to the SiteGuard server on your network.</string>
	<key>UIStatusBarStyle</key>
	<string>UIStatusBarStyleLightContent</string>
	<key>NSAppTransportSecurity</key>
	<dict>
		<key>NSAllowsLocalNetworking</key>
		<true/>
		<key>NSAllowsArbitraryLoadsInWebContent</key>
		<true/>
	</dict>
`;
    const end = s.lastIndexOf('</dict>');
    return s.slice(0, end) + keys + s.slice(end);
  });
  copy('resources/ios/AppIcon-512@2x.png', 'ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png');
  for (const name of ['splash-2732x2732.png', 'splash-2732x2732-1.png', 'splash-2732x2732-2.png'])
    copy('resources/ios/splash-2732x2732.png', `ios/App/App/Assets.xcassets/Splash.imageset/${name}`);
}

run('npx cap sync');
console.log(`
Done.
  Android: npm run android   (opens Android Studio, then press Run)
  iPhone:  npm run ios       (on a Mac: opens Xcode, then press Run)`);
